ThinkPad Battery Chrage threshold without admin and vantage

This "program" is the result of me not beeing to set a battery charge threshold on my new work issued ThinkPad but the winodows store is blocked by IT and im a only a standard user.
Don't get me wrong, i could make my account to admin rights if i wanted to but to avoid any incidents i decided to work arround it. Which is good since this is how this batch "program" was born.

Turns out Lenovos battery threshold is managed by the Lenovo Power and battery driver which is then triggered or disabled by Lenovo Vantage. But the best part is it can be triggered by other things,
like the program ChargeThreshold.exe that Lenovo themself made. I included this program in the zip but here is the link anyway: https://download.lenovo.com/pccbbs//thinkvantage_en/metroapps/Vantage/ChargeThreshold/ChargeThreshold.exe

This is great! The program runs simply with launchung it with a CMD window(it does not have to be elevated) in its directory and giving it a value to set the battery % at.

example: ChargeThreshold.exe 80 70

The problem: making a .bat file would be easy but my antivirus makes this not beeing an option. So thats when it hit me: build a shortcut to cmd.exe, launch it in its directory and enter the desired values. In this directory there are
different shortcuts and instructions on how to use it.

Use this tiny (800kB ish) program instead of Lenovos bloated vantage as you wish but don't sell it.
